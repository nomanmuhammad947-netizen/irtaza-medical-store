# Irtaza Medical Store: APK banane ke steps

Yeh ek chhota Android (WebView) project hai jo https://irtaza-med-flow.base44.app ko app ki tarah kholta hai.

## APK banane ka tareeqa (computer ke baghair, free)

1. github.com par free account banayein (agar nahi hai) aur **New repository** banayein, naam: `irtaza-medical-store`.
2. Repository mein **Add file → Upload files** par jaayein. Is ZIP ko extract karke **andar ka saara content** (app folder, .github folder, settings.gradle, build.gradle, gradle.properties wagaira) drag-drop karein. `.github` folder zaroor upload hona chahiye.
3. **Commit changes** dabayein.
4. Upar **Actions** tab kholein. "Build APK" chalta nazar aayega (3-5 minute lagte hain). Na chale to "Build APK" → **Run workflow** dabayein.
5. Green tick aane par us run par click karein. Neeche **Artifacts** mein `Irtaza-Medical-Store-APK` download karein.
6. ZIP extract karke `app-debug.apk` ko phone mein bhej dein aur install karein (Unknown sources ki ijazat dena pad sakti hai).

## Cheezein badalni hon to

- App ka link: `app/src/main/java/com/irtaza/medicalstore/MainActivity.java` mein `APP_URL`
- App ka naam: `app/src/main/res/values/strings.xml`
- Icon: `app/src/main/res/mipmap-*/` ke `ic_launcher.png`
